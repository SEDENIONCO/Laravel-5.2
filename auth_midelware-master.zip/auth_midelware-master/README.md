# auth_midelware
Simple auth and roles administration in laravel 
